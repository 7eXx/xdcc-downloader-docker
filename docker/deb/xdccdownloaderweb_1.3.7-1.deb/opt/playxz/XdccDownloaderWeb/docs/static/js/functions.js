$(document).ready(function(){
    setInterval(function() {
        $("#download_list").load("download_list_reload");
        $("#log_list").load("logs_reload");
        
        if(document.getElementById('searchProgressBar') != null){
            if($("#searchProgressBar").attr("value") != "100"){
                console.log($("#searchProgressBar").attr("value"));            
                $("#search_results").load("search_reload");
            };
        };
        //~ $("#search_results").load("search_reload");
    }, 3000);
    $("#home-button").click(function(){
        var Url = "/home";
        window.location.href = Url;
        // var win = window.open("http://playxz.altervista.org/blog/xdccdownloader-web/", '_blank');
    }); 
    $("#prefs-button").click(function(){
        var Url = "/get_settings";
        window.location.href = Url;
    });
    $("#customdb-button").click(function(){
        var Url = "/customdb_edit";
        window.location.href = Url;
    });
    $('#downloads-button').click(function(){
        var Url = "/download_list";
        window.location.href = Url;
    });    
    $('#search-button').click(function(){
        var Url = "/search_page";
        window.location.href = Url;   
    });    
    $('#news-button').click(function(){
        var Url = "/news";
        window.location.href = Url;   
        submitted();
    });
    $('#logs-button').click(function(){
        var Url = "/logs";
        window.location.href = Url;   
    });
    $('#logout-button').click(function(){
        var Url = "/logout";
        window.location.href = Url;   
    });
    $('#compact-button').click(function(){
        var Url = "/";
        window.location.href = Url;   
    });
    $('#delete-complete-download-button').click(function(){
        $.get("/erase_complete_downloads"); 
    });    
    $('#delete-error-download-button').click(function(){
        $.get("/erase_error_downloads"); 
    });     
    
})



function execute_query( cmd ) {
    $.get(
        cmd  
    );
    return false;
}

function search_request(cmd)
{
    var objJSON = {
        "query": cmd
    };
    $.post(
        "../search_json",
        {query : JSON.stringify(objJSON)},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                show_message_diaolog("Errore", "La ricerca non e' stata aggiunta alla coda. Errore: " + r.error);
            }
            else
            {
                show_message_diaolog("Ricerca aggiunta", "La ricerca e' stata correttamente aggiunta alla coda.");
            }
        }
    );
    return false;
    
}


function download_request(cmd)
{
    var objJSON = {
        "cmd": cmd
    };
    $.post(
        "../download_json",
        {query : JSON.stringify(objJSON)},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                //~ alert('page content: ' + r.error);
                show_message_diaolog("Errore", "Il download non e' stato aggiunto alla coda. Errore: " + r.error);
            }
            else
            {
                show_message_diaolog("Download aggiunto", "Il download e' stato correttamente aggiunto alla coda.");
            }
        }
    );
    return false;
    
}

function show_message_diaolog(title, message)
{
    $('#dialog-result').dialog('option', 'title', title);
    document.getElementById("dialog-result_message").innerHTML = message;
    $( "#dialog-result" ).dialog("open");
}

function refresh_cache_query( ) {
    var file_cache = document.getElementById('list_cache').value;
    $.get(
        "../refresh_cache_json",
        {query : file_cache},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                //~ alert('page content: ' + r.error);
                document.getElementById("refresh_result").innerHTML = "Errore refresh: "+r.error;
            }
            else
            {
                document.getElementById("refresh_result").innerHTML = "Refresh avvenuto!";
            }
        }
    );
    return false;
    //~ window.alert(file_cache);
}

function send_message_to_server(key, message)
{
    var objJSON = {
        "cmd": key,
        "message": message
    };
    $.post(
        "../send_message_to_channel_json",
        {query : JSON.stringify(objJSON)},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                //~ alert('page content: ' + r.error);
                document.getElementById("result_message").innerHTML = "Errore nell'invio del messaggio al canale: "+r.error;
            }
            else
            {
                document.getElementById("result_message").innerHTML = "Messaggio inviato correttamente al canale!";
            }
        }
    );
    return false;
    
}

function send_message_to_bot(key, message)
{
    var objJSON = {
        "cmd": key,
        "message": message
    };
    $.post(
        "../send_message_to_bot_json",
        {query : JSON.stringify(objJSON)},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                //~ alert('page content: ' + r.error);
                document.getElementById("result_message").innerHTML = "Errore nell'invio del messaggio al bot: "+r.error;
            }
            else
            {
                document.getElementById("result_message").innerHTML = "Messaggio inviato correttamente al bot!";
            }
        }
    );
    return false;
    
}

function send_message_to_user(key, message, user)
{
    var objJSON = {
        "cmd": key,
        "message": message,
        "user": user
    };
    $.post(
        "../send_message_to_user_json",
        {query : JSON.stringify(objJSON)},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                //~ alert('page content: ' + r.error);
                document.getElementById("result_message").innerHTML = "Errore nell'invio del messaggio al bot: "+r.error;
            }
            else
            {
                document.getElementById("result_message").innerHTML = "Messaggio inviato correttamente al bot!";
            }
        }
    );
    return false;
    
}

//~ Funzione per inviare la nuova configurazione al server
function save_config_query()
{
    var objJSON = {
        "RESUME_DOWNLOADS" : document.getElementById('restore_downloads').checked,
        "SSL" : document.getElementById('SSL').checked,
        "SEARCH_CACHE" : document.getElementById('gfind_search').checked,
        "SEARCH_POWERSCRIPT" : document.getElementById('search_powerscript').checked,
        "SEARCH_CUSTOM_CACHE" : document.getElementById('gfind_custom_search').checked,
        "SEARCH_XDCC_IT" : document.getElementById('xdccfinderit_search').checked,
        "SEARCH_SUNXDCC" : document.getElementById('sunxdcc_search').checked,
        "SEARCH_PROTINUS" : document.getElementById('protinus_search').checked,
        "SEARCH_IXIRC" : document.getElementById('ixirc_search').checked,
        "SEARCH_IRCBOT" : document.getElementById('ircbot_search').checked,
        "SCHEDULER" : document.getElementById('enable_scheduler').checked,
        "SCHEDULER_START" : document.getElementById('time_start_downloads').value,
        "SCHEDULER_END" : document.getElementById('time_stop_downloads').value,
        "USERNAME" : document.getElementById('username').value,
        "NICKSERV_MAIL" : document.getElementById('nickserv_mail').value,
        "NICKSERV_PW" : document.getElementById('nickserv_pw').value,
        "DB_FILE" : document.getElementById('list_cache').value,        
        "CUSTOM_DB_FILE" : document.getElementById('personal_list').value,        
        "DB_URL" : document.getElementById('Url lista').value,
        "SEARCH_POWERSCRIPT_URL" : document.getElementById('url_powerscript').value,
        "NEWS_URL" : document.getElementById('url_news').value,
        "SIM_DOWNLOAD" : document.getElementById('cuncurrent_downloads').value,
        "DOWNLOAD_PATH" : document.getElementById('save_path').value,
        "END_DOWNLOAD_ACTION" : document.getElementById('end_download_action').value,
        "AUTHENTICATION" : document.getElementById('enable_authentication').checked,
        "WEB_USERNAME" : document.getElementById('web_username').value,
        "WEB_PASSWORD" : document.getElementById('web_password').value,
        "HTTPS" : document.getElementById('enable_https').checked,
        "ENABLE_MAIL" : document.getElementById('enable_mail').checked,
        "MAIL_USER" : document.getElementById('mail_user').value,
        "MAIL_PASSWORD" : document.getElementById('mail_password').value,
        "MAIL_TO" : document.getElementById('mail_to').value,
        "SMTP_SERVER" : document.getElementById('smtp_server').value,
        "SMTP_PORT" : document.getElementById('smtp_port').value
    };
    //~ window.alert(JSON.stringify(objJSON));
    $.post(
        "../save_config_json",
        {query : JSON.stringify(objJSON)},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                //~ alert('page content: ' + r.error);
                show_message_diaolog("Errore", "Errore savataggio modifiche: "+r.error);
            }
            else
            {
                show_message_diaolog("Salvataggio avvenuto", "Savataggio modifiche avvenuto!");
            }
        }
    );
    return false;
}

//~ Funzione per inviare il db custom al server
function save_customdb_query()
{
    var frm = $(document.customdb);
    // window.alert(JSON.stringify(frm.serializeArray()));
    $.post(
        "../save_customdb_json",
        {query : JSON.stringify(frm.serializeArray())},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                //~ alert('page content: ' + r.error);
                show_message_diaolog("Errore", "Errore savataggio modifiche: "+r.error);
            }
            else
            {
                // show_message_diaolog("Salvataggio avvenuto", "Savataggio modifiche avvenuto!");
                var Url = "/customdb_edit";
                window.location.href = Url;
            }
        }
    );
    return false;
}
//~ Funzione per testare il servizio di mailing
function test_mail_service()
{
    var objJSON = {
        "MAIL_USER" : document.getElementById('mail_user').value,
        "MAIL_PASSWORD" : document.getElementById('mail_password').value,
        "MAIL_TO" : document.getElementById('mail_to').value,
        "SMTP_SERVER" : document.getElementById('smtp_server').value,
        "SMTP_PORT" : document.getElementById('smtp_port').value
    };
    $.post(
        "../test_mail_json",
        {query : JSON.stringify(objJSON)},
        function(data) {
            var r = JSON.parse(data);
            if (r.error != ""){
                //~ alert('page content: ' + r.error);
                show_message_diaolog("Errore", "Errore inviando la mail: "+r.error);
            }
            else
            {
                show_message_diaolog("Mail inviata", "Controlla la casella postale!");
            }
        }
    );
    return false;
}

function change_news_key()
{
    var category = document.getElementById('news_category').value;
    $.get(
        "../change_news_key",
        {query : category},
        function(data) {
                //~ alert('page content: ' + r.error);
                document.getElementById("title_news").innerHTML = data;            
        }
    );
    return false;
}

//~ Funzione per bloccare la pagina in seguito a una ricerca
function submitted() {
    document.getElementById('submitteddisplay').style.display = 'block';
}

function submitted_done() {
    document.getElementById('submitteddisplay').style.display = 'none';
}

//~ Funzione per mostrare una delle ricerche effettuate in passato
function past_search_changed() {
    var seleced_search = document.getElementById('past_search').options[document.getElementById('past_search').selectedIndex].text;
    var Url = "../get_past_search?query=" + seleced_search;
    window.location.href = Url;
}






//~ <a href="/"><input type="submit" value="HOME" style="margin-right: 20px;"/></a>
    //~ <a href="/download_list"><input type="submit" value="DOWNLOADS" style="margin-right: 20px;" /></a>
    //~ <a href="../get_settings"><input type="submit" value="SETTINGS" style="margin-right: 20px;" /></a>
    //~ <a href="/news"><input type="submit" value="NEWS" style="margin-right: 20px;"/></a>
    //~ <a href="/logs"><input type="submit" value="LOG"/></a>
//~ $(function() {
      //~ $('.progressbar').each(function() {
            //~ var progressbar = $(this);
            //~ progressLabel = $(this).find( ".progress-label" );
            //~ var progressvalue = parseInt($(this).attr("value"));
            //~ console.log(progressvalue);
            //~ progressbar.progressbar({value: progressvalue});
            //~ progressLabel.text( progressbar.progressbar( "value" ) + "% Complete" );
      //~ });
//~ });
