#!/bin/sh
script='/opt/playxz/XdccDownloaderWeb/XdccDownloaderServer.pyc'
/usr/bin/python $script &
